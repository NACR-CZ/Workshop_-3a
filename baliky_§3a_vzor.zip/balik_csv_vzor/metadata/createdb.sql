CREATE TABLE "schema"."obdobi"
(
    "obdobi"        integer,
    "nuts"          character varying
);

CREATE TABLE "schema"."stupen"
(
    "stupen"        integer,
    "kod"          integer,
	"nazev"			 character varying
);

